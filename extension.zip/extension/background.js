// background.js - Service worker for background processes

try {
  importScripts('content/shared.js');
} catch (e) {
  console.error('[WatchSync] Failed to load shared.js', e);
}

const syncManager = new SyncManager();
let roomState = {
  roomId: null,
  isHost: false,
  participants: [],
  platform: null,
  connected: false
};

// WebSocket Event Listeners
syncManager.on('room_created', (room) => {
  roomState.roomId = room.roomId;
  roomState.isHost = true;
  roomState.participants = room.participants;
  roomState.platform = room.platform;
  roomState.connected = true;
  updateStorage();
  
  // Store room data in Firebase
  FirebaseAPI.setRoomData(room.roomId, {
    hostId: room.hostId,
    platform: room.platform,
    createdAt: room.createdAt,
    participants: room.participants
  });
  
  notifyPopup('room_status_changed', roomState);
});

syncManager.on('room_joined', (room) => {
  roomState.roomId = room.roomId;
  roomState.isHost = false;
  roomState.participants = room.participants;
  roomState.platform = room.platform;
  roomState.connected = true;
  updateStorage();
  notifyPopup('room_status_changed', roomState);
});

syncManager.on('participant_joined', (data) => {
  roomState.participants = data.room.participants;
  updateStorage();
  notifySidebar('participant_joined', data);
});

syncManager.on('participant_left', (data) => {
  roomState.participants = data.room.participants;
  updateStorage();
  notifySidebar('participant_left', data);
});

syncManager.on('host_changed', (data) => {
  // If I am the new host
  if (data.newHostId === syncManager.ws.url /* We don't have socket.id easily, this is just an example */ ) {
    // We would need the server to tell us our own socket.id to know for sure
    // For now, let the popup/sidebar determine if they are the host by checking socket ID.
  }
  notifySidebar('host_changed', data);
  notifyPopup('room_status_changed', roomState);
});

syncManager.on('incoming_sync', (data) => {
  // Forward sync to active tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, {
        type: 'INCOMING_SYNC',
        data: data
      });
    }
  });
});

syncManager.on('chat_message', (data) => {
  notifySidebar('chat_message', data);
});

syncManager.on('reaction', (data) => {
  notifySidebar('reaction', data);
});

// Extension Message Listeners
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'CREATE_ROOM') {
    syncManager.connect();
    
    // Determine platform from active tab URL
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      let platform = 'unknown';
      if (tabs[0] && tabs[0].url) {
        if (tabs[0].url.includes('netflix.com')) platform = 'netflix';
        else if (tabs[0].url.includes('hotstar.com') || tabs[0].url.includes('jiohotstar.com')) platform = 'hotstar';
      }
      
      // Wait slightly for connection to establish before emitting
      setTimeout(() => {
        syncManager.emit('create_room', { platform });
      }, 500);
    });
    
    sendResponse({ status: 'connecting' });
  } 
  else if (request.type === 'JOIN_ROOM') {
    syncManager.connect();
    const name = request.name || 'Guest';
    
    setTimeout(() => {
      syncManager.emit('join_room', { roomId: request.roomId, name });
    }, 500);
    
    sendResponse({ status: 'connecting' });
  }
  else if (request.type === 'PLAYER_EVENT') {
    if (roomState.isHost && roomState.connected) {
      syncManager.emit('player_event', {
        roomId: roomState.roomId,
        type: request.event,
        currentTime: request.currentTime
      });
    }
  }
  else if (request.type === 'GET_ROOM_STATE') {
    sendResponse(roomState);
  }
  else if (request.type === 'SEND_CHAT') {
    syncManager.emit('chat_message', {
      roomId: roomState.roomId,
      name: request.name,
      message: request.message,
      videoTimestamp: request.videoTimestamp
    });
    
    FirebaseAPI.addChatMessage(roomState.roomId, {
      name: request.name,
      text: request.message,
      videoTimestamp: request.videoTimestamp
    });
  }
  else if (request.type === 'SEND_REACTION') {
    syncManager.emit('reaction', {
      roomId: roomState.roomId,
      emoji: request.emoji
    });
  }
  else if (request.type === 'LEAVE_ROOM') {
    if (syncManager.ws) {
      syncManager.ws.close();
      syncManager.ws = null;
    }
    
    roomState = {
      roomId: null,
      isHost: false,
      participants: [],
      platform: null,
      connected: false
    };
    updateStorage();
    sendResponse({ status: 'left' });
  }
  
  return true;
});

function updateStorage() {
  chrome.storage.local.set({ roomState });
}

function notifyPopup(action, data) {
  chrome.runtime.sendMessage({ action, data }).catch(() => {});
}

function notifySidebar(action, data) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { action, data }).catch(() => {});
    }
  });
}
